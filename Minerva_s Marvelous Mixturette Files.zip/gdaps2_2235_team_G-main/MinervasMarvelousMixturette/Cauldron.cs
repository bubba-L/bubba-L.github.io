﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MinervasMarvelousMixturette
{
    /// <summary>
    /// A class representing a cauldron. Holds orders and brews them while they are inside.
    /// </summary>
    internal class Cauldron
    {
        // Fields
        // The order in the cauldron
        Order heldOrder;

        // The key associated with the cauldron
        Keys associatedKey;

        // Display rectangle
        Rectangle displayRectangle;

        // Normal cauldron asset
        Texture2D normalCauldronAsset;

        // Bubbling cauldron asset
        Texture2D bubblingCauldronAsset;

        // Font
        SpriteFont font;

        // Constructor
        /// <summary>
        /// Create a new Cauldron
        /// </summary>
        /// <param name="displayRectangle">The rectangle for the Cauldron's position</param>
        /// <param name="associatedKey">The key associated with the Cauldron.</param>
        public Cauldron(Rectangle displayRectangle, Keys associatedKey)
        {
            this.displayRectangle = displayRectangle;
            this.associatedKey = associatedKey;
        }

        /// <summary>
        /// Update this cauldron
        /// </summary>
        /// <param name="gameTime">The current gameTime.</param>
        public void Update(GameTime gameTime)
        {
            // If holding an order, increment the held order's brew time.
            if (heldOrder != null)
            {
                heldOrder.BrewAmount += gameTime.ElapsedGameTime.TotalSeconds;
            }
        }

        /// <summary>
        /// Draw this cauldron
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        public void Draw(SpriteBatch sb)
        {
            // If there is no order inside, draw the normal asset.
            if (heldOrder == null)
            {
                sb.Draw(normalCauldronAsset, displayRectangle, Color.White);
            }
            // If there is an order, draw the bubbling asset with the brew amount of the order inside.
            else
            {
                sb.Draw(bubblingCauldronAsset, displayRectangle, Color.White);
                sb.DrawString(font, ((int)heldOrder.BrewAmount).ToString(), new Vector2(displayRectangle.X + 94, displayRectangle.Y + 124), Color.Orange);
            }

            // Draw the key associated with the cauldron.
            sb.DrawString(font, associatedKey.ToString(), new Vector2(displayRectangle.X + 94, displayRectangle.Y + 94), Color.White);
        }

        /// <summary>
        /// A property for the held order. Gets and sets.
        /// </summary>
        public Order HeldOrder
        {
            get
            {
                return heldOrder;
            }

            set
            {
                heldOrder = value;
            }
        }

        /// <summary>
        /// A property for the key associated with the cauldron. Gets.
        /// </summary>
        public Keys AssociatedKey
        {
            get
            {
                return associatedKey;
            }
        }

        /// <summary>
        /// A property for the cauldron's position rectangle. Gets.
        /// </summary>
        public Rectangle Position
        {
            get
            {
                return displayRectangle;
            }
        }

        /// <summary>
        /// Load the textures for the cauldron
        /// </summary>
        /// <param name="normalCauldronAsset">The normal cauldron asset</param>
        /// <param name="bubblingCauldronAsset">The bubbling cauldron asset</param>
        /// <param name="font"></param>
        public void LoadTextures(Texture2D normalCauldronAsset, Texture2D bubblingCauldronAsset, SpriteFont font)
        {
            this.normalCauldronAsset = normalCauldronAsset;
            this.bubblingCauldronAsset = bubblingCauldronAsset;
            this.font = font;
        }
    }
}
