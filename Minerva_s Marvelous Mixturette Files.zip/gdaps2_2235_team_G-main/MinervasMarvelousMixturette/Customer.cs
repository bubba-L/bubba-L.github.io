﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MinervasMarvelousMixturette
{
    /// <summary>
    /// A class representing a customer. Has an order, enters at a certain time and 
    /// leaves after they run out of patience.
    /// </summary>
    internal class Customer
    {
        // Fields
        // Hold an order
        private Order order;

        // Enter at a certain time
        private int entryTime;

        // Leave after patience is zero
        private double patience;

        // The asset of this customer.
        private Texture2D asset;


        // Gauge 
        Gauge gauge;

        // Constructors
        /// <summary>
        /// Create a new specific customer 
        /// </summary>
        /// <param name="asset">The customer's asset</param>
        /// <param name="position">The customer's position</param>
        /// <param name="order">The customer's order</param>
        /// <param name="entryTime">The time the customer enters</param>
        /// <param name="patience">The customer's patience</param>
        /// <param name="gaugeAsset">The gauge's asset</param>
        public Customer(Texture2D asset, Order order, int entryTime, int patience, Texture2D gaugeAsset)
        {
            this.asset = asset;
            this.order = order;
            this.entryTime = entryTime;
            this.patience = patience;

            gauge = new Gauge(patience, gaugeAsset);
        }

        // Methods

        /// <summary>
        /// Update this customer
        /// </summary>
        /// <param name="gameTime">The current GameTime</param>
        public void Update(GameTime gameTime)
        {
            return;
        }

        /// <summary>
        /// Draw this customer at a given position.
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        /// <param name="position">The position and dimensions of the customer's asset</param>
        public void Draw(SpriteBatch sb, Rectangle position)
        {
            sb.Draw(asset, position, Color.White);
        }

        /// <summary>
        /// Draw this customer and their gauge at a given position.
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        /// <param name="position">The position and dimensions of the customer's asset</param>
        /// <param name="gaugePosition">The position and dimensions of the gauge</param>
        public void Draw(SpriteBatch sb, Rectangle position, Rectangle gaugePosition)
        {
            sb.Draw(asset, position, Color.White);
            gauge.Draw(sb, patience, gaugePosition);
        }

        /// <summary>
        /// A property for this customer's order. Gets.
        /// </summary>
        public Order Order
        {
            get
            {
                return order;
            }
        }

        /// <summary>
        /// A property for the customer's patience. Gets and sets.
        /// </summary>
        public double Patience
        {
            get
            {
                return patience;
            }
            set
            {
                patience = value;
            }
        }

        /// <summary>
        /// A property for the entry time of the customer. Gets.
        /// </summary>
        public int EntryTime
        {
            get
            {
                return entryTime;
            }
        }

        /// <summary>
        /// Provide information about a customer.
        /// </summary>
        /// <returns>A string about a customer</returns>
        public override string ToString()
        {
            return order.ToString() + $"\n\nEntry Time: {entryTime}\n\nPatience: {(int)patience}";
        }
    }
}
