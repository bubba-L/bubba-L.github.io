﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

public enum GameState
{
    MainMenu,
    LevelSelect,
    Score,
    Gameplay,
}
// A delegate for changing gamestates.
public delegate void ChangeToStateDelegate(GameState s);

// A delegate for loading the level from level select.
public delegate void LoadLevelFromString(string s);

// A delegate for a key press on this frame.
public delegate bool SingleKeyPressDelegate(Keys k);

// A delegate for a key being held.
public delegate bool KeyHeldDelegate(Keys k);

namespace MinervasMarvelousMixturette
{
    /// <summary>
    /// Game1 is the manager of managers, calling what should happen from the classes managing the different screens.
    /// </summary>
    public class Game1 : Game
    {

        // Fields
        //      Assets
        // SpriteFonts
        private SpriteFont arial12;

        // 1x1 Pixel asset
        public Texture2D pixelAsset;

        // A boolean for determining if an exception has occured.
        private bool error = false;


        //      Gameplay fields
        // Game State Manager Enum
        private GameState gameState;

        // Keyboard states
        private KeyboardState kbState;
        private KeyboardState previousKbState;

        // Game State Objects
        private MainMenu mainMenu;
        private LevelSelect levelSelect;
        private Gameplay gameplay;
        private Scores scores;

        //      Necessary for Game1
        // Graphics manager
        private GraphicsDeviceManager _graphics;

        // Spritebatch
        private SpriteBatch _spriteBatch;

        // Constructor
        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);

            // Change the screen size
            _graphics.PreferredBackBufferWidth = 1280;
            _graphics.PreferredBackBufferHeight = 720;

            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        // Methods
        protected override void Initialize()
        {
            // Initialize the game state to the main menu
            gameState = GameState.MainMenu;

            // Initialize the main menu class
            mainMenu = new MainMenu();

            // Assign its delegates
            mainMenu.ChangeState = ChangeToState;
            mainMenu.SingleKeyPress = SingleKeyPress;

            // Initialize the gameplay class
            gameplay = new Gameplay();

            // Assign its delegates
            gameplay.ChangeState = ChangeToState;
            gameplay.SingleKeyPress = SingleKeyPress;
            gameplay.KeyHeld = KeyHeld;

            // Initialize the level select class
            levelSelect = new LevelSelect();

            // Assign its delegates
            levelSelect.ChangeState = ChangeToState;
            levelSelect.SingleKeyPress = SingleKeyPress;
            levelSelect.LoadLevel = gameplay.LoadLevel;

            // Initialize the score screen
            scores = new Scores();

            // Assign its delegates
            scores.ChangeState = ChangeToState;
            scores.SingleKeyPress = SingleKeyPress;


            // Base Game initialization
            base.Initialize();
        }

        protected override void LoadContent()
        {
            // Initialize the spritebatch
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // Load the content for the game state classes
            mainMenu.LoadContent(Content);
            levelSelect.LoadContent(Content);
            gameplay.LoadContent(Content);
            scores.LoadContent(Content);

            // Load the arial spritefont
            arial12 = Content.Load<SpriteFont>("arial12");

            // Load the 1x1 pixel
            pixelAsset = Content.Load<Texture2D>("pixel");


        }

        protected override void Update(GameTime gameTime)
        {
            // Exit the game if Escape is pressed.
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed ||
                Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // Get the current keyboard state
            kbState = Keyboard.GetState();

            try
            {
                // Update based on the current gamestate
                switch (gameState)
                {
                    case GameState.MainMenu:
                        mainMenu.Update(gameTime);
                        break;

                    case GameState.LevelSelect:
                        levelSelect.Update(gameTime);
                        break;

                    case GameState.Gameplay:
                        gameplay.Update(gameTime);
                        break;

                    case GameState.Score:
                        scores.Update(gameTime);
                        break;

                }
            }
            catch (System.Exception e)
            {
                gameState = GameState.MainMenu;
                error = true;
            }

            // Store this frame's keyboard state so it can be referenced next frame.
            previousKbState = kbState;

            // Base Game update
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            // Draw the background
            GraphicsDevice.Clear(Color.White);

            // Begin drawing
            _spriteBatch.Begin();

            // Draw based on the game's state
            switch (gameState)
            {
                case GameState.MainMenu:
                    mainMenu.Draw(_spriteBatch, error);
                    break;

                case GameState.LevelSelect:
                    levelSelect.Draw(_spriteBatch);
                    break;

                case GameState.Gameplay:
                    gameplay.Draw(_spriteBatch);
                    break;

                case GameState.Score:
                    scores.Draw(_spriteBatch);
                    break;

            }

            // Base Game draw
            base.Draw(gameTime);

            // End drawing
            _spriteBatch.End();
        }

        /// <summary>
        /// Detect if a key is pressed once on a given frame
        /// </summary>
        /// <param name="key">The key to check</param>
        /// <returns>A bool, whether or not the key was pressed this frame</returns>
        public bool SingleKeyPress(Keys key)
        {
            return (kbState.IsKeyDown(key) && previousKbState.IsKeyUp(key));
        }

        /// <summary>
        /// Detect if a key is currently held
        /// </summary>
        /// <param name="k">The key to check/param>
        /// <returns>A bool, whether or not the key is held</returns>
        public bool KeyHeld(Keys k)
        {
            return kbState.IsKeyDown(k);
        }

        /// <summary>
        /// Change the game state to a given gamestate
        /// </summary>
        /// <param name="gameState">The game state to change to</param>
        private void ChangeToState(GameState gameState)
        {
            this.gameState = gameState;
        }


    }
}