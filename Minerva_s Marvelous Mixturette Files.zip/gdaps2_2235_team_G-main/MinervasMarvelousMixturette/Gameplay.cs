﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.IO;

enum GameplayState
{
    Order,
    Mix,
    Brew,
    Finish
}

enum AssetNames
{
    witch,
    wizard
}

namespace MinervasMarvelousMixturette
{
    /// <summary>
    /// The class that manages the gameplay. Managed by Game1.
    /// </summary>
    public class Gameplay
    {
        // Fields
        //      Assets
        // Fonts
        private SpriteFont smallFont;
        private SpriteFont mediumFont;
        private SpriteFont largeFont;

        // The list of assets that the customers use
        private List<Texture2D> assets;

        // A 1x1 pixel asset
        private Texture2D pixelAsset;

        // Cauldron assets
        private Texture2D normalCauldron;
        private Texture2D bubblingCauldron;

        // Hud Icons
        private Texture2D border;
        private Texture2D orderIndicator;
        private Texture2D mixIndicator;
        private Texture2D brewIndicator;
        private Texture2D finishIndicator;

        // Backgrounds
        private Texture2D orderBackground;
        private Texture2D mixBackground;
        private Texture2D brewBackground;
        private Texture2D finishBackground;

        // Ingredient icons + their dictionary
        private Dictionary<int, Texture2D> ingredientIconAssets;
        private Texture2D unihorn;
        private Texture2D eyeofnewt;
        private Texture2D orchid;
        private Texture2D hardroot;
        private Texture2D beans;
        private Texture2D crystal;
        private Texture2D baby;
        private Texture2D nightmare;
        private Texture2D mucus;

        // Potion
        private Texture2D potion;

        // Tutorial Images
        private Texture2D[] tutorialAssets;

        //      Gameplay fields
        // Gameplay state
        private GameplayState gameplayState;

        // The time since the level started
        private double levelTime;

        // A timer for decreasing patience once per second.
        private double secondTimer;

        // The current order being modified on each screen
        private Order currentMixOrder;
        private Order currentBrewOrder;
        private Order currentFinishOrder;

        // Queues for passing orders inbetween stations
        private Queue<Order> brewOrderQueue;
        private Queue<Order> finishOrderQueue;

        // The list of customers for the current level
        private List<Customer> customers;

        // The list of currently active customers
        private List<Customer> activeOrderCustomers;
        private List<Customer> activeFinishCustomers;

        // The current customer
        private Customer currentOrderCustomer;
        private Customer currentFinishCustomer;

        // The cauldrons and an array to contain them
        Cauldron uCauldron;
        Cauldron oCauldron;
        Cauldron bCauldron;
        Cauldron mCauldron;
        Cauldron[] cauldrons;

        // The level number
        private int levelNumber;

        // The total score
        private int totalScore;

        // Screen Width Constant
        private const int screenWidth = 1280;

        // God Mode
        private bool godMode;

        // Pause
        private bool paused;

        // Win/Loss
        bool won;
        bool lost;

        // Tutorial booleans
        bool[] tutorialsPassed;

        //      Delegates, assigned in Game1
        // Delegate for changing state
        public ChangeToStateDelegate ChangeState;

        // Delegate for single key presses
        public SingleKeyPressDelegate SingleKeyPress;

        // Delegate for held keys
        public KeyHeldDelegate KeyHeld;

        // Constructor
        /// <summary>
        /// Create a new gameplay manager
        /// </summary>
        public Gameplay()
        {
            // Initialize the gameplay state to ordering
            gameplayState = GameplayState.Order;

            // Initalize the asset list
            assets = new List<Texture2D>();

            // Initialize the customer lists
            customers = new List<Customer>();
            activeOrderCustomers = new List<Customer>();
            activeFinishCustomers = new List<Customer>();

            // Initialize the current order on the mix screen
            currentMixOrder = new Order();

            // Initialize the order queues
            brewOrderQueue = new Queue<Order>();
            finishOrderQueue = new Queue<Order>();

            // Initialize the ingredient asset dictionary
            ingredientIconAssets = new Dictionary<int, Texture2D>();

            // Initialize the cauldrons
            uCauldron = new Cauldron(new Rectangle(625, 70, 200, 200), Keys.U);
            oCauldron = new Cauldron(new Rectangle(895, 75, 200, 200), Keys.O);
            bCauldron = new Cauldron(new Rectangle(600, 360, 200, 200), Keys.B);
            mCauldron = new Cauldron(new Rectangle(870, 365, 200, 200), Keys.M);
            cauldrons = new Cauldron[] { uCauldron, oCauldron, bCauldron, mCauldron };

            // Initialize the pause boolean.
            paused = false;

            // Initialize the ending booleans
            won = false;
            lost = false;

            // Initialize the tutorial image list and tutorial booleans
            tutorialAssets = new Texture2D[4];
            tutorialsPassed = new bool[4];
            for (int i = 0; i < 4; i++)
            {
                tutorialsPassed[i] = false;
            }
        }

        // Methods

        /// <summary>
        /// Load the relevant content for gameplay
        /// </summary>
        /// <param name="content">The content manager to load the content</param>
        public void LoadContent(ContentManager Content)
        {
            // Load the font
            smallFont = Content.Load<SpriteFont>("arial12");
            mediumFont = Content.Load<SpriteFont>("LevelNumberFont");
            largeFont = Content.Load<SpriteFont>("SelectedLevelNumberFont");

            // Load the customer assets
            assets.Add(Content.Load<Texture2D>("witch"));
            assets.Add(Content.Load<Texture2D>("wizard"));

            // Load the pixel asset
            pixelAsset = Content.Load<Texture2D>("pixel");

            // Load the ingredient assets
            ingredientIconAssets[0] = unihorn = Content.Load<Texture2D>("unicornhorn");
            ingredientIconAssets[1] = eyeofnewt = Content.Load<Texture2D>("eyeofnewt");
            ingredientIconAssets[2] = orchid = Content.Load<Texture2D>("orchid");
            ingredientIconAssets[3] = hardroot = Content.Load<Texture2D>("hardroot");
            ingredientIconAssets[4] = beans = Content.Load<Texture2D>("jumpingbeans");
            ingredientIconAssets[5] = crystal = Content.Load<Texture2D>("crystal");
            ingredientIconAssets[6] = baby = Content.Load<Texture2D>("baby");
            ingredientIconAssets[7] = nightmare = Content.Load<Texture2D>("nightmare");
            ingredientIconAssets[8] = mucus = Content.Load<Texture2D>("mucus");


            // Load the cauldron assets
            normalCauldron = Content.Load<Texture2D>("normalcauldron");
            bubblingCauldron = Content.Load<Texture2D>("bubblingcauldron");

            // Assign the cauldron assets
            foreach (Cauldron cauldron in cauldrons)
            {
                cauldron.LoadTextures(normalCauldron, bubblingCauldron, smallFont);
            }

            // Hud Icons
            border = Content.Load<Texture2D>("border");
            orderIndicator = Content.Load<Texture2D>("order");
            mixIndicator = Content.Load<Texture2D>("mix");
            brewIndicator = Content.Load<Texture2D>("brew");
            finishIndicator = Content.Load<Texture2D>("finish");

            // Backgrounds
            orderBackground = Content.Load<Texture2D>("orderBG");
            mixBackground = Content.Load<Texture2D>("mixBG");
            brewBackground = Content.Load<Texture2D>("brewBG");
            finishBackground = Content.Load<Texture2D>("orderBG");

            // Potion
            potion = Content.Load<Texture2D>("potion");

            // Tutorial Assets
            tutorialAssets[0] = Content.Load<Texture2D>("orderTutorial");
            tutorialAssets[1] = Content.Load<Texture2D>("mixTutorial");
            tutorialAssets[2] = Content.Load<Texture2D>("brewTutorial");
            tutorialAssets[3] = Content.Load<Texture2D>("finishTutorial");
        }

        /// <summary>
        /// Update the gameplay 
        /// </summary>
        /// <param name="gameTime">The current GameTime</param>
        public void Update(GameTime gameTime)
        {
            // If the tutorial for this station hasn't been passed, run the tutorial update
            if (!tutorialsPassed[(int)gameplayState])
            {
                UpdateTutorial(gameTime);
            }
            // If you've won, update the win screen.
            else if (won)
            {
                UpdateWinScreen(gameTime);
            }
            // If you've lost, update the loss screen.
            else if (lost)
            {
                UpdateLossScreen(gameTime);
            }
            // If you've paused, update the pause screen.
            else if (paused)
            {
                UpdatePauseScreen();
            }
            // If not in any special state, run the gameplay loop.
            else
            {
                // Update everything that needs to update every frame
                GlobalUpdate(gameTime);

                // Update based on the gameplay state
                switch (gameplayState)
                {
                    case GameplayState.Order:
                        UpdateOrder(gameTime);
                        break;

                    case GameplayState.Mix:
                        UpdateMix(gameTime);
                        break;

                    case GameplayState.Brew:
                        UpdateBrew(gameTime);
                        break;

                    case GameplayState.Finish:
                        UpdateFinish(gameTime);
                        break;
                }
            }
        }

        /// <summary>
        /// Draw the gameplay screen
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        public void Draw(SpriteBatch sb)
        {
            // If you've won, draw the win screen
            if (won)
            {
                DrawWinScreen(sb);
            }
            // If you've lost, draw the loss screen.
            else if (lost)
            {
                DrawLossScreen(sb);
            }
            // If you're paused, draw the pause screen.
            else if (paused)
            {
                DrawPauseScreen(sb);
            }
            // Otherwise, draw the gameplay.
            else
            {
                // Draw based on the gameplay state
                switch (gameplayState)
                {
                    case GameplayState.Order:
                        DrawOrder(sb);
                        break;

                    case GameplayState.Mix:
                        DrawMix(sb);
                        break;

                    case GameplayState.Brew:
                        DrawBrew(sb);
                        break;

                    case GameplayState.Finish:
                        DrawFinish(sb);
                        break;
                }

                // Draw global drawings
                GlobalDraw(sb);

                // Draw the tutorials if necessary
                if (!tutorialsPassed[(int)gameplayState])
                {
                    DrawTutorial(sb);
                }
            }
        }

        /// <summary>
        /// Change the gameplay state, and wrap around the ends. Gets and sets.
        /// </summary>
        private int GameplayStateProperty
        {
            // Return the integer equivalent of the gameplay state
            get
            {
                return (int)gameplayState;
            }

            set
            {
                // If the set value is less than zero, go to the last station (finishing)
                if (value < 0)
                {
                    gameplayState = GameplayState.Finish;
                }
                // If the value is greater than three, go to the first station (ordering)
                else if (value > 3)
                {
                    gameplayState = GameplayState.Order;
                }
                // Otherwise set the gameplay state to the inputted value
                else
                {
                    gameplayState = (GameplayState)value;
                }
            }
        }

        #region Loading level and reset
        /// <summary>
        /// Load a given list of customers for a level from a string of level information.
        /// </summary>
        /// <param name="levelInformation">The level information</param>
        public void LoadLevel(string levelInformation)
        {
            // Reset the game
            Reset();

            // Split the level information so it can be processed
            string[] splitInfo = levelInformation.Split('\n');

            // Create a variable for the number of customers to be loaded.
            int numCustomers;

            // Load in the level name and the number of customers.
            int.TryParse(splitInfo[0], out levelNumber);
            int.TryParse(splitInfo[1], out numCustomers);

            // Set the baseline for reading information
            int baseLine = 1;

            // Create blank variables to hold the necessary information before making a customer.
            Texture2D customerAsset;
            Order customerOrder;
            string[] orderStringList;
            List<Ingredient> customerIngredients;
            List<Topping> customerToppings;
            int customerBrewAmount;
            int customerEntryTime;
            int customerPatience;

            // Load in the customers
            for (int i = 0; i < numCustomers; i++)
            {
                // Load the customer's asset using it's name and the AssetNames enum.
                // Loads the asset from the asset list associated with the value of the enum.
                customerAsset =
                    assets[(int)Enum.Parse(typeof(AssetNames), splitInfo[baseLine + 2])];

                // Split another string to process information about the ingredients
                orderStringList = splitInfo[baseLine + 3].Split(',');

                // Create a new list of ingredients
                customerIngredients = new List<Ingredient>();

                // Add the ingredients from the string to the list.
                foreach (string str in orderStringList)
                {
                    customerIngredients.Add((Ingredient)Enum.Parse(typeof(Ingredient), str));
                }

                // Set the brew time
                int.TryParse(splitInfo[baseLine + 4], out customerBrewAmount);

                // Split another string to process information about the toppings
                orderStringList = splitInfo[baseLine + 5].Split(',');

                // Create a new list of toppings
                customerToppings = new List<Topping>();

                /*
                // Add the toppings from the string to the list
                foreach (string str in orderStringList)
                {
                    customerToppings.Add((Topping)Enum.Parse(typeof(Topping), str));
                }
                */

                // Create the customer's order based on the given values
                customerOrder =
                    new Order(customerIngredients, customerBrewAmount, customerToppings);

                // Load the customer's entry time and patience
                int.TryParse(splitInfo[baseLine + 6], out customerEntryTime);

                int.TryParse(splitInfo[baseLine + 7], out customerPatience);

                // Create the customer with all of the relevant values
                customers.Add(new Customer(customerAsset,
                    customerOrder, customerEntryTime, customerPatience, pixelAsset));

                // Move the base line to the start of the next customer.
                baseLine += 8;
            }
        }

        /// <summary>
        /// Reset the gameplay
        /// </summary>
        private void Reset()
        {
            // Reset the customer lists
            customers = new List<Customer>();
            activeOrderCustomers = new List<Customer>();
            activeFinishCustomers = new List<Customer>();

            // Reset the current order on the screen
            currentMixOrder = new Order();

            // Set the orders on other screens to null
            currentBrewOrder = null;
            currentFinishOrder = null;

            // Reset the order queues
            brewOrderQueue = new Queue<Order>();
            finishOrderQueue = new Queue<Order>();

            // Reset the timer
            levelTime = 0;

            // Reset the score
            totalScore = 0;

            // Reset the cauldrons
            foreach (Cauldron cauldron in cauldrons)
            {
                cauldron.HeldOrder = null;
            }

            // Reset the gameplay state
            gameplayState = GameplayState.Order;

            // Reset win/loss/pause
            paused = false;
            won = false;
            lost = false;
        }

        #endregion
        #region Global
        /// <summary>
        /// Update everything that needs to update regardless of station.
        /// </summary>
        /// <param name="gameTime">The current GameTime</param>
        public void GlobalUpdate(GameTime gameTime)
        {
            // Update both timers
            levelTime += gameTime.ElapsedGameTime.TotalSeconds;

            // Add customers if the level time is greater or equal to than their entry time
            for (int i = 0; i < customers.Count; i++)
            {
                if (customers[i].EntryTime <= levelTime)
                {
                    activeOrderCustomers.Add(customers[i]);
                    customers.RemoveAt(i);
                    i -= 1;
                }
            }

            // Brew orders in cauldrons
            foreach (Cauldron cauldron in cauldrons)
            {
                cauldron.Update(gameTime);
            }

            // Decrease customer patience in the active customer lists.
            foreach (Customer customer in activeOrderCustomers)
            {
                customer.Patience -= gameTime.ElapsedGameTime.TotalSeconds;
            }
            foreach (Customer customer in activeFinishCustomers)
            {
                customer.Patience -= gameTime.ElapsedGameTime.TotalSeconds;
            }

            // Lose if customer patience is zero unless in god mode
            if (!godMode)
            {

                // If a customer's patience is zero in either queue, go to the level select
                foreach (Customer customer in activeOrderCustomers)
                {
                    if (customer.Patience <= 0)
                    {
                        lost = true;
                    }
                }
                foreach (Customer customer in activeFinishCustomers)
                {
                    if (customer.Patience <= 0)
                    {
                        lost = true;
                    }
                }
            }

            // Win if all the customers are gone
            if (customers.Count == 0 && activeFinishCustomers.Count == 0 && activeOrderCustomers.Count == 0)
            {
                SaveScore();
                won = true;
            }

            // Navigate between states using A and D
            if (SingleKeyPress(Keys.D))
            {
                GameplayStateProperty += 1;
            }
            if (SingleKeyPress(Keys.A))
            {
                GameplayStateProperty -= 1;
            }

            // Go into God Mode if right control is pressed.
            if (SingleKeyPress(Keys.RightControl))
            {
                godMode = !godMode;
            }

            // Pause if backspace is pressed
            if (SingleKeyPress(Keys.Back))
            {
                paused = true;
            }

            // Skip all  tutorials if enter is pressed.
            if (SingleKeyPress(Keys.Enter))
            {
                for (int i = 0; i < 4; i++)
                {
                    tutorialsPassed[i] = true;
                }
            }
        }

        /// <summary>
        /// Draw everything that needs to be drawn regardless of station
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        private void GlobalDraw(SpriteBatch sb)
        {
            // Draw the hud
            sb.Draw(border, Vector2.Zero, Color.White);

            // Draw the order indicator and the spacebar indicator
            switch (gameplayState)
            {
                case GameplayState.Order:
                    sb.Draw(orderIndicator, Vector2.Zero, Color.White);
                    break;

                case GameplayState.Mix:
                    sb.Draw(mixIndicator, Vector2.Zero, Color.White);
                    break;

                case GameplayState.Brew:
                    sb.Draw(brewIndicator, Vector2.Zero, Color.White);
                    break;

                case GameplayState.Finish:
                    sb.Draw(finishIndicator, Vector2.Zero, Color.White);
                    break;
            }

            // If tab is held then draw the taken order display
            if (KeyHeld(Keys.Tab))
            {
                // Draw the backdrop
                sb.Draw(pixelAsset, new Rectangle(0, 0, 300, 720), Color.Gray);
                sb.Draw(pixelAsset, new Rectangle(5, 5, 290, 710), Color.LightGray);

                // For the first 4 taken customers
                // (or less if there are less than 4 taken customers)
                for (int i = 0; i < Math.Min(4, activeFinishCustomers.Count); i++)
                {
                    // draw the customer
                    activeFinishCustomers[i].Draw(sb, new Rectangle(5, 5 + 175 * i, 50, 100), new Rectangle(5, 105 + 175 * i, 50, 25));

                    //draw their order
                    DrawOrderIcons(sb, activeFinishCustomers[i].Order, new Vector2(55, 5 + 175 * i));

                    // write the brew time
                    sb.DrawString(smallFont, $"Brew Time: {activeFinishCustomers[i].Order.BrewAmount}", new Vector2(5, 130 + 175 * i), Color.Orange);
                }
            }

            // Draw the score
            sb.DrawString(smallFont, $"Score: {totalScore}", new Vector2(1050, 685), Color.Purple);

            // Draw an indicator for god mode
            if (godMode)
            {
                sb.DrawString(smallFont, "god mode", new Vector2(8, 685), Color.Gold);
            }
        }

        /// <summary>
        /// Draw an order's ingredients as icons
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        /// <param name="o">The order to draw</param>
        /// <param name="position">The position to draw the order icons from</param>
        private void DrawOrderIcons(SpriteBatch sb, Order o, Vector2 position)
        {
            for (int i = 0; i < o.IngredientCount; i++)
            {
                sb.Draw(ingredientIconAssets[(int)o.Ingredients[i]], new Rectangle((int)(position.X + ((i % 3) * 50)), (int)position.Y + ((i / 3) * 50), 50, 50), Color.White);
            }
        }

        /// <summary>
        /// Draw a string centered
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        /// <param name="spriteFont">The spritefont to use</param>
        /// <param name="text">The text to draw</param>
        /// <param name="position">The position of the center of the text</param>
        /// <param name="color">The color of the text</param>
        private void DrawStringCentered(SpriteBatch sb, SpriteFont spriteFont, string text, Vector2 position, Color color)
        {
            Vector2 stringSize = spriteFont.MeasureString(text);

            sb.DrawString(spriteFont, text, new Vector2((int)position.X - stringSize.X / 2, position.Y - stringSize.Y / 2), color);
        }
        #endregion
        #region Order
        /// <summary>
        /// Update everything that occurs on the order screen
        /// </summary>
        /// <param name="gameTime">The current GameTime</param>
        private void UpdateOrder(GameTime gameTime)
        {
            // If there are more than 0 customers in the Order screen queue
            if (activeOrderCustomers.Count > 0)
            {
                // And space is pressed
                if (SingleKeyPress(Keys.Space))
                {
                    // Move the customer between the queues.
                    activeFinishCustomers.Add(activeOrderCustomers[0]);
                    activeOrderCustomers.RemoveAt(0);
                }
            }
        }

        /// <summary>
        /// Draw everything that is on the order screen
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        private void DrawOrder(SpriteBatch sb)
        {
            // Draw the first 3 customers in a line
            for (int i = 2; i >= 0; i--)
            {
                if (i < activeOrderCustomers.Count)
                {
                    activeOrderCustomers[i].Draw(sb, new Rectangle(370 + 100 * i, 270, 100, 200));
                }
            }

            // Draw the background (which is the foreground)
            sb.Draw(orderBackground, Vector2.Zero, Color.White);

            // Draw the current customer's order
            if (activeOrderCustomers.Count != 0)
            {
                DrawOrderIcons(sb, activeOrderCustomers[0].Order, new Vector2(780, 150));
                sb.DrawString(smallFont, $"Brew time: {activeOrderCustomers[0].Order.BrewAmount}", new Vector2(780, 350), Color.Orange);
            }
        }
        #endregion

        #region Mix
        /// <summary>
        /// Update everything that happens on the mix screen
        /// </summary>
        /// <param name="gameTime">The current GameTime</param>
        private void UpdateMix(GameTime gameTime)
        {

            // Modify the ingredients based on user input
            ModifyIngredientsFromInput();

            // If the current order has more than 0 ingredients and space is pressed
            if (currentMixOrder.IngredientCount > 0 && SingleKeyPress(Keys.Space))
            {
                //add it to the queue
                brewOrderQueue.Enqueue(currentMixOrder);

                //create a new order
                currentMixOrder = new Order();
            }

            // If T is pressed, trash the current order.
            if (SingleKeyPress(Keys.T))
            {
                currentMixOrder = new Order();
            }
        }

        /// <summary>
        /// Draw everything on the mix screen
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        private void DrawMix(SpriteBatch sb)
        {
            // Draw the background
            sb.Draw(mixBackground, Vector2.Zero, Color.White);

            // Draw the order
            DrawOrderIcons(sb, currentMixOrder, new Vector2(150, 360));

        }

        /// <summary>
        /// Modify the current order's ingredients based on user input
        /// </summary>
        private void ModifyIngredientsFromInput()
        {
            // For the associated key, add an ingredient if the key is pressed
            // but remove it if control is held.
            if (SingleKeyPress(Keys.U))
            {
                currentMixOrder.ModifyIngredient(Ingredient.UnicornHorn, KeyHeld(Keys.LeftControl));
            }
            if (SingleKeyPress(Keys.I))
            {
                currentMixOrder.ModifyIngredient(Ingredient.EyeOfNewt, KeyHeld(Keys.LeftControl));
            }
            if (SingleKeyPress(Keys.O))
            {
                currentMixOrder.ModifyIngredient(Ingredient.Orchid, KeyHeld(Keys.LeftControl));
            }
            if (SingleKeyPress(Keys.H))
            {
                currentMixOrder.ModifyIngredient(Ingredient.Hardroot, KeyHeld(Keys.LeftControl));
            }
            if (SingleKeyPress(Keys.J))
            {
                currentMixOrder.ModifyIngredient(Ingredient.JumpingBeans, KeyHeld(Keys.LeftControl));
            }
            if (SingleKeyPress(Keys.K))
            {
                currentMixOrder.ModifyIngredient(Ingredient.Crystal, KeyHeld(Keys.LeftControl));
            }
            if (SingleKeyPress(Keys.B))
            {
                currentMixOrder.ModifyIngredient(Ingredient.Baby, KeyHeld(Keys.LeftControl));
            }
            if (SingleKeyPress(Keys.N))
            {
                currentMixOrder.ModifyIngredient(Ingredient.Nightmare, KeyHeld(Keys.LeftControl));
            }
            if (SingleKeyPress(Keys.M))
            {
                currentMixOrder.ModifyIngredient(Ingredient.Mucus, KeyHeld(Keys.LeftControl));
            }
        }
        #endregion

        #region Brew
        /// <summary>
        /// Update everything that happens on the brew screen
        /// </summary>
        /// <param name="gameTime"></param>
        private void UpdateBrew(GameTime gameTime)
        {
            // Move orders into cauldrons based on input
            BrewOrderFromInput();

            // If T is pressed, trash the current order
            if (SingleKeyPress(Keys.T) && brewOrderQueue.Count != 0)
            {
                brewOrderQueue.Dequeue();
            }
        }

        /// <summary>
        /// Draw everything that happens on the brew screen
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        private void DrawBrew(SpriteBatch sb)
        {
            // Draw background
            sb.Draw(brewBackground, Vector2.Zero, Color.White);

            // Draw the order
            if (brewOrderQueue.Count > 0)
            {
                DrawOrderIcons(sb, brewOrderQueue.Peek(), new Vector2(150, 360));
            }

            // Draw the cauldrons
            for (int i = 0; i < 4; i++)
            {
                cauldrons[i].Draw(sb);
                Console.WriteLine(i);
            }

            // Show inside all cauldrons if space is held
            if (KeyHeld(Keys.Space))
            {
                RevealBrew(sb);
            }
        }

        /// <summary>
        /// Place orders into cauldrons based on user input
        /// </summary>
        private void BrewOrderFromInput()
        {
            // For each cauldron
            foreach (Cauldron cauldron in cauldrons)
            {
                // Check their key
                if (SingleKeyPress(cauldron.AssociatedKey))
                {
                    // If the cauldron is empty, but the current order into it
                    if (cauldron.HeldOrder == null)
                    {
                        if (brewOrderQueue.Count != 0)
                        {
                            cauldron.HeldOrder = brewOrderQueue.Dequeue();
                        }

                    }

                    // If it is full, empty the cauldron and pass the order to the next station
                    else
                    {
                        finishOrderQueue.Enqueue(cauldron.HeldOrder);
                        cauldron.HeldOrder = null;
                    }

                }
            }
        }

        /// <summary>
        /// Reveal cauldron contents
        /// </summary>
        private void RevealBrew(SpriteBatch sb)
        {
            // For each cauldron
            foreach (Cauldron cauldron in cauldrons)
            {
                // If it is not empty
                if (cauldron.HeldOrder != null)
                {
                    // Draw its contents on top of the cauldron
                    DrawOrderIcons(sb, cauldron.HeldOrder, new Vector2(cauldron.Position.X + 25, cauldron.Position.Y + 25));
                }
            }
        }
        #endregion

        #region Finish
        /// <summary>
        /// Update everything that happens on the finish screen
        /// </summary>
        /// <param name="gameTime">The current GameTime</param>
        private void UpdateFinish(GameTime gameTime)
        {
            //if they press space
            if (SingleKeyPress(Keys.Space))
            {
                // Deliver and score order.
                if (finishOrderQueue.Count != 0 && activeFinishCustomers.Count != 0)
                {
                    totalScore += (int)Compare(finishOrderQueue.Dequeue(), activeFinishCustomers[0].Order);
                    activeFinishCustomers.RemoveAt(0);
                }

            }
            // If T is pressed, trash the current order.
            if (SingleKeyPress(Keys.T) && finishOrderQueue.Count > 0)
            {
                finishOrderQueue.Dequeue();
            }

        }

        /// <summary>
        /// Draw everything that is on the finish screen
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        private void DrawFinish(SpriteBatch sb)
        {
            // Draw the first 3 customers in a line
            for (int i = 2; i >= 0; i--)
            {
                if (i < activeFinishCustomers.Count)
                {
                    activeFinishCustomers[i].Draw(sb, new Rectangle(370 + 100 * i, 270, 100, 200), new Rectangle(370 + 100 * i, 220, 100, 50));
                }
            }

            // Draw background
            sb.Draw(finishBackground, Vector2.Zero, Color.White);

            // Draw the potion if there is an order
            if (finishOrderQueue.Count > 0)
            {
                sb.Draw(potion, new Vector2(570, 500), Color.White);
            }

            // Draw the current customer's order
            if (activeFinishCustomers.Count != 0)
            {
                DrawOrderIcons(sb, activeFinishCustomers[0].Order, new Vector2(780, 150));
                sb.DrawString(smallFont, $"Brew time: {activeFinishCustomers[0].Order.BrewAmount}", new Vector2(780, 350), Color.Orange);
            }

        }

        /// <summary>
        /// compare the current order with the customer's order
        /// </summary>
        /// <param name="currentOrder">the order being made</param>
        /// <param name="customerOrder">the customer's order</param>
        /// <returns>the score</returns>
        private double Compare(Order currentOrder, Order customerOrder)
        {
            //the score based on the performance
            double score = 0;

            //for each ingredient in the current order being made
            foreach (Ingredient ingredient in currentOrder.Ingredients)
            {
                //if the customer order has the ingredient 
                if (customerOrder.Ingredients.Contains(ingredient))
                {
                    //add to the score
                    score += 10;
                }

                //if the ingredient is not present
                else
                {
                    //reduce the score
                    score -= 2;
                }
            }

            //for all the toppings in the current order
            foreach (Topping toppings in currentOrder.Toppings)
            {
                //if the customer order has the topping
                if (customerOrder.Toppings.Contains(toppings))
                {
                    //increase the score
                    score += 10;
                }

                //if it doesn't contains
                else
                {
                    //reduce the score
                    score -= 2;
                }
            }

            //if the brew amount is less than or greater than the brew amount by 10
            if (currentOrder.BrewAmount <= (customerOrder.BrewAmount + 10)
                && currentOrder.BrewAmount >= (customerOrder.BrewAmount - 10))
            {
                //increase the score by 10
                score += 10;
            }

            //if not
            else
            {
                //reduce the score by 5
                score -= 5;
            }

            //if the patience is greater than 0
            if (activeFinishCustomers.Count != 0 && activeFinishCustomers[0].Patience > 0)
            {
                //multiply the score by the percent of the patience
                score *= (activeFinishCustomers[0].Patience * 0.03);
            }

            //return the score
            return score;
        }

        #endregion


        #region Pause
        /// <summary>
        /// Update everything happening on the pause screen
        /// </summary>
        private void UpdatePauseScreen()
        {
            // If enter is pressed go back to level select
            if (SingleKeyPress(Keys.Enter))
            {
                ChangeState(GameState.LevelSelect);
            }

            // If backspace is pressed, unpause
            if (SingleKeyPress(Keys.Back))
            {
                paused = false;
            }
        }

        /// <summary>
        /// Draw the pause screen
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        private void DrawPauseScreen(SpriteBatch sb)
        {
            // Draw the pause information
            sb.DrawString(smallFont, "Paused\nPress Backspace to return to the game\nOr press Enter to return to level select", Vector2.Zero, Color.Black);
        }
        #endregion

        #region Win/Loss
        /// <summary>
        /// Update the win screen
        /// </summary>
        /// <param name="gameTime">The current GameTime</param>
        private void UpdateWinScreen(GameTime gameTime)
        {
            // If enter is pressed go to level select
            if (SingleKeyPress(Keys.Enter))
            {
                ChangeState(GameState.LevelSelect);
            }
        }
        /// <summary>
        /// Draw the win screen
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        private void DrawWinScreen(SpriteBatch sb)
        {
            DrawStringCentered(sb, largeFont, "You Won!", new Vector2(640, 250), Color.Purple);
            DrawStringCentered(sb, mediumFont, $"You scored {totalScore} points!", new Vector2(640, 325), Color.Purple);
            DrawStringCentered(sb, mediumFont, "Press Enter to return to level select", new Vector2((screenWidth / 2), 380), Color.Purple);
        }

        /// <summary>
        /// Update the loss screen
        /// </summary>
        /// <param name="gameTime">The current GameTime</param>
        private void UpdateLossScreen(GameTime gameTime)
        {
            // If enter is pressed go to level select
            if (SingleKeyPress(Keys.Enter))
            {
                ChangeState(GameState.LevelSelect);
            }
        }

        /// <summary>
        /// Draw the loss screen
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        private void DrawLossScreen(SpriteBatch sb)
        {
            sb.DrawString(largeFont, "You Lost :(", new Vector2(1280 / 2 - 150, 200), Color.Purple);
            sb.DrawString(mediumFont, "Press Enter to return to level select", new Vector2((screenWidth / 2) - (64 * 6), 300), Color.Purple);
        }

        /// <summary>
        /// Save a score to the score list, and write it to the file.
        /// </summary>
        private void SaveScore()
        {
            // Create a string to score the current line
            string lineOfText = "";
            List<int> scoresList = new List<int>();
            StreamReader reader = null;
            StreamWriter writer = null;

            try
            {
                // Attempt to load the level's scores
                reader =
                    new StreamReader($"../../../../resources/Scores/Scores{levelNumber}.txt");

                // Add each score from the file to the score list
                while ((lineOfText = reader.ReadLine()) != null)
                {
                    // Adds the score to the list
                    scoresList.Add(int.Parse(lineOfText));


                    // If there are more than 5 scores
                    while (scoresList.Count > 5)
                    {
                        // Remove the sixth item from the list
                        scoresList.Remove(scoresList[5]);
                    }
                }

                // Add this score
                scoresList.Add(totalScore);

                // Create a list to store the sorted list
                List<int> sortedList = new List<int>();

                // Create a temporary variable to hold the highest value
                int highest = 0;

                // Find the highest values and add them to a new list.
                for (int i = 0; i < 5; i++)
                {
                    // Find the highest
                    foreach (int score in scoresList)
                    {
                        if (score >= highest)
                        {
                            highest = score;
                        }

                    }

                    // Add it to the sorted list
                    sortedList.Add(highest);

                    // Remove it from the original list
                    scoresList.Remove(highest);

                    // Reset the highest value
                    highest = 0;
                }

                // Set the scorelist to the sorted list
                scoresList = sortedList;

                // Close the reader if it is not null
                if (reader != null)
                {
                    reader.Close();
                }

                // Attempt to open the relevant score file
                writer =
                    new StreamWriter($"../../../../resources/Scores/Scores{levelNumber}.txt");

                // If the writer is not null and the score list is not null
                if (writer != null && scoresList != null)
                {
                    // Write each score to the list.
                    for (int i = 0; i < 5; i++)
                    {
                        writer.WriteLine(scoresList[i]);
                    }
                }
            }
            catch
            {
                // Set the score list to null if the scorelist can't be loaded
                scoresList = null;
            }
            finally
            {
                // Close the writer if it exists
                if (writer != null)
                {
                    writer.Close();
                }

            }

        }

        #endregion

        #region Tutorials
        /// <summary>
        /// Update everything that happens while a tutorial is showing
        /// </summary>
        /// <param name="gameTime">The current GameTime</param>
        private void UpdateTutorial(GameTime gameTime)
        {
            // If space is pressed, pass the tutorial
            if (SingleKeyPress(Keys.Space))
            {
                tutorialsPassed[(int)gameplayState] = true;
            }

            // Skip all tutorials if enter is pressed.
            if (SingleKeyPress(Keys.Enter))
            {
                for (int i = 0; i < 4; i++)
                {
                    tutorialsPassed[i] = true;
                }
            }

        }

        /// <summary>
        /// Draw the tutorial for this station
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        private void DrawTutorial(SpriteBatch sb)
        {
            sb.Draw(tutorialAssets[(int)gameplayState], new Vector2(50, 400), Color.White);
        }
        #endregion
    }
}

