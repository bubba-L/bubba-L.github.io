﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MinervasMarvelousMixturette
{
    /// <summary>
    /// A class representing a gauge. Implemented to work with any integers, but is used only for customer patience.
    /// </summary>
    internal class Gauge
    {
        // Fields
        // The maximum value of the gauge
        private float maxValue;

        // Proportion between max and current value
        double proportionOfMax;

        // Rectangle for the inner bar
        int innerWidth;
        Rectangle innerRectangle;

        // Inner gauge color
        Color barColor;

        // Asset
        private Texture2D asset;

        // Methods
        /// <summary>
        /// Create a new gauge
        /// </summary>
        /// <param name="maxValue">The maximum value of the gauge</param>
        /// <param name="asset">The 1x1 pixel asset</param>
        public Gauge(int maxValue, Texture2D asset)
        {
            // Set the max value and create a rectangle based on the inputted values
            this.maxValue = maxValue;

            // Assign the asset
            this.asset = asset;
        }

        /// <summary>
        /// Draw this gauge
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        /// <param name="value">The current value of the associated value of the gauge</param>
        /// <param name="gaugeRectangle">The rectangle for the outer rectangle of the gauge</param>
        public void Draw(SpriteBatch sb, double value, Rectangle gaugeRectangle)
        {
            // Draw the larger bar
            sb.Draw(asset, gaugeRectangle, Color.Gray);

            // Calculate the proportion of maximum 
            proportionOfMax = (value / maxValue);

            innerWidth = (int)(gaugeRectangle.Width * 0.9);
            innerRectangle.Height = (int)(gaugeRectangle.Height * 0.8);

            // Calculate and set the width of the smaller bar
            innerRectangle.Width = (int)(innerWidth * proportionOfMax);

            // Update the position of the inner rectangle
            innerRectangle.X = gaugeRectangle.X + (int)(0.05 * gaugeRectangle.Width);
            innerRectangle.Y = gaugeRectangle.Y + (int)(0.1 * gaugeRectangle.Height);

            // Change the color of the bar based on the proportion of input to maximum
            if (proportionOfMax >= 0.5)
            {
                barColor = Color.Green;
            }

            else if (proportionOfMax >= 0.3)
            {
                barColor = Color.Yellow;
            }

            else if (proportionOfMax >= 0.15)
            {
                barColor = Color.Orange;
            }

            else
            {
                barColor = Color.Red;
            }

            // Draw the inner rectangle
            sb.Draw(asset, innerRectangle, barColor);
        }

    }
}
