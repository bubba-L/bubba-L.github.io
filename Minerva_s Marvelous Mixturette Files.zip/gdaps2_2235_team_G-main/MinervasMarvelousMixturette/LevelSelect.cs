﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using System.IO;



namespace MinervasMarvelousMixturette
{
    /// <summary>
    /// A class representing the level select screen. Managed in Game1.
    /// </summary>
    public class LevelSelect
    {
        //      Asset Fields
        // Images for the levels
        private List<Texture2D> levelImages;

        // Text Font
        private SpriteFont arial12;
        private SpriteFont levelNumberFont;
        private SpriteFont selectedLevelNumberFont;

        //      Delegates, assigned in Game1
        // Delegate for changing states
        public ChangeToStateDelegate ChangeState;

        // Delegate for loading a level
        public LoadLevelFromString LoadLevel;

        // Delegate for single keypresses
        public SingleKeyPressDelegate SingleKeyPress;

        // An integer representing the selected level.
        private int selectedLevel;

        // Constructor
        public LevelSelect()
        {
            // Initialize the selected level to be invalid.
            selectedLevel = -1;
        }

        /// <summary>
        /// Load the content for the level select
        /// </summary>
        /// <param name="Content">The content manager to load the content</param>
        public void LoadContent(ContentManager Content)
        {
            arial12 = Content.Load<SpriteFont>("arial12");
            levelNumberFont = Content.Load<SpriteFont>("LevelNumberFont");
            selectedLevelNumberFont = Content.Load<SpriteFont>("SelectedLevelNumberFont");
        }

        /// <summary>
        /// update the level selection
        /// </summary>
        /// <param name="gameTime">the current game time in frames</param>
        public void Update(GameTime gameTime)
        {
            try
            {
                // If enter is pressed, change to the main menu state
                if (SingleKeyPress(Keys.Enter))
                {
                    ChangeState(GameState.MainMenu);
                }

                // Check if a number key is pressed
                // If one is pressed then select the associated level
                for (int i = (int)(Keys.D1); i < (int)(Keys.D6); i++)
                {
                    if (SingleKeyPress((Keys)i))
                    {
                        selectedLevel = i - 48;
                    }
                }

                // If space is pressed and a level is selected then load that level.
                if (SingleKeyPress(Keys.Space) && selectedLevel != -1)
                {
                    LoadLevel(LoadLevelString(selectedLevel));
                    ChangeState(GameState.Gameplay);
                }
            }
            catch (System.Exception e)
            {
                ChangeState(GameState.MainMenu);
            }
        }

        /// <summary>
        /// Draw the level select screen
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        public void Draw(SpriteBatch sb)
        {
            //Position of selected level number
            Vector2 largeNumberPosition = new Vector2();

            // Instructional Text
            sb.DrawString(arial12, "Level Select\nPress enter to go to main menu.",
                Vector2.Zero, Color.Indigo);
            sb.DrawString(arial12, "\n\nPress a number to select a level" +
                "\nThen press space to load the level.",
                Vector2.Zero, Color.Indigo);


            //Checking if a level is selected
            if (selectedLevel != -1)
            {

                //Makes the selected number larger and draws the rest
                switch (selectedLevel)
                {
                    case 1:
                        largeNumberPosition = new Vector2(selectedLevel * (1280 / 6), 275);
                        sb.DrawString(levelNumberFont, "2", new Vector2(2 * (1280 / 6), 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "3", new Vector2(3 * (1280 / 6), 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "4", new Vector2(4 * (1280 / 6), 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "5", new Vector2(5 * (1280 / 6), 300), Color.Purple);
                        break;
                    case 2:
                        largeNumberPosition = new Vector2(selectedLevel * (1280 / 6), 275);
                        sb.DrawString(levelNumberFont, "1", new Vector2(1280 / 6, 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "3", new Vector2(3 * (1280 / 6), 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "4", new Vector2(4 * (1280 / 6), 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "5", new Vector2(5 * (1280 / 6), 300), Color.Purple);
                        break;
                    case 3:
                        largeNumberPosition = new Vector2(selectedLevel * (1280 / 6), 275);
                        sb.DrawString(levelNumberFont, "1", new Vector2(1280 / 6, 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "2", new Vector2(2 * (1280 / 6), 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "4", new Vector2(4 * (1280 / 6), 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "5", new Vector2(5 * (1280 / 6), 300), Color.Purple);
                        break;
                    case 4:
                        largeNumberPosition = new Vector2(selectedLevel * (1280 / 6), 275);
                        sb.DrawString(levelNumberFont, "1", new Vector2(1280 / 6, 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "2", new Vector2(2 * (1280 / 6), 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "3", new Vector2(3 * (1280 / 6), 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "5", new Vector2(5 * (1280 / 6), 300), Color.Purple);
                        break;
                    case 5:
                        largeNumberPosition = new Vector2(selectedLevel * (1280 / 6), 275);
                        sb.DrawString(levelNumberFont, "1", new Vector2(1280 / 6, 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "2", new Vector2(2 * (1280 / 6), 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "3", new Vector2(3 * (1280 / 6), 300), Color.Purple);
                        sb.DrawString(levelNumberFont, "4", new Vector2(4 * (1280 / 6), 300), Color.Purple);
                        break;
                }

                //Drawing selected number at correct position
                sb.DrawString(selectedLevelNumberFont, selectedLevel.ToString(),
                    largeNumberPosition, Color.Purple);
            }
            else
            {
                //Drawing all level numbers, deselected
                sb.DrawString(levelNumberFont, "1", new Vector2(1280 / 6, 300), Color.Purple);
                sb.DrawString(levelNumberFont, "2", new Vector2(2 * (1280 / 6), 300), Color.Purple);
                sb.DrawString(levelNumberFont, "3", new Vector2(3 * (1280 / 6), 300), Color.Purple);
                sb.DrawString(levelNumberFont, "4", new Vector2(4 * (1280 / 6), 300), Color.Purple);
                sb.DrawString(levelNumberFont, "5", new Vector2(5 * (1280 / 6), 300), Color.Purple);
            }
        }

        /// <summary>
        /// Load the text from a level file.
        /// </summary>
        /// <param name="level">The level number to load</param>
        /// <returns></returns>
        private string LoadLevelString(int level)
        {
            // Create a string to hold the level's information
            string levelString;

            // Try to read the level's information into the string
            try
            {
                StreamReader reader =
                    new StreamReader($"../../../../resources/Levels/level{level}.txt");
                levelString = reader.ReadToEnd();

                // Close the reader if it opened.
                if (reader != null)
                {
                    reader.Close();
                }
            }
            // If it didn't work, the level string is a null string.
            catch
            {
                levelString = null;
            }
            // Return the level string
            return levelString;
        }


    }
}
