﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MinervasMarvelousMixturette
{
    /// <summary>
    /// A class representing the main menu. Managed by Game1.
    /// </summary>
    public class MainMenu
    {
        // Font
        private SpriteFont arial12;
        private Texture2D logo;

        //      Delegates, assigned in Game1
        // Delegate for changing state
        public ChangeToStateDelegate ChangeState;

        // Delegate for single key presses
        public SingleKeyPressDelegate SingleKeyPress;

        /// <summary>
        /// Create a new main menu object
        /// </summary>
        public MainMenu()
        {

        }

        /// <summary>
        /// Load the relevant content for the main menu
        /// </summary>
        /// <param name="Content">The content manager to load the content with</param>
        public void LoadContent(ContentManager Content)
        {
            // Spritefont
            arial12 = Content.Load<SpriteFont>("arial12");

            // Logo
            logo = Content.Load<Texture2D>("logo");

        }

        /// <summary>
        /// Update the main menu screen
        /// </summary>
        /// <param name="gameTime">The current GameTime</param>
        public void Update(GameTime gameTime)
        {
            // If enter is pressed, change to the level select state.
            if (SingleKeyPress(Keys.Enter))
            {
                ChangeState(GameState.LevelSelect);
            }

            // If s is pressed, change to the score state.
            if (SingleKeyPress(Keys.S))
            {
                ChangeState(GameState.Score);
            }
        }

        /// <summary>
        /// Draw the main menu screen
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        public void Draw(SpriteBatch sb, bool error)
        {
            // Draw the logo
            sb.Draw(logo, new Rectangle(640 - logo.Width / 2, 360 - logo.Height / 2, logo.Width, logo.Height), Color.White);

            // Draw the information text
            sb.DrawString(arial12, "Enter to go to level select" +
                "\nS to go to the score screen", Vector2.Zero, Color.Black);

            // If an error occured inform the player (but hopefully only the developer)
            if (error)
            {
                sb.DrawString(arial12, "Error occurred.", new Vector2(100, 100), Color.Black);
            }
        }
    }
}
