﻿using System;
using System.Collections.Generic;

enum Ingredient
{
    UnicornHorn,
    EyeOfNewt,
    Orchid,
    Hardroot,
    JumpingBeans,
    Crystal,
    Baby,
    Nightmare,
    Mucus
}

enum Topping
{
}

namespace MinervasMarvelousMixturette
{
    /// <summary>
    /// A class representing an order. Used by Customer and Gameplay.
    /// </summary>
    internal class Order
    {
        // Fields
        // List of ingredients
        private List<Ingredient> ingredients;

        // The brew amount
        private double brewAmount;

        // List of toppings
        private List<Topping> toppings;

        /// <summary>
        /// A property for the brew amount. Gets and sets.
        /// </summary>
        public double BrewAmount
        {
            get
            {
                return brewAmount;
            }
            set
            {
                brewAmount = value;
            }
        }

        /// <summary>
        /// A property for the ingredient count. Gets.
        /// </summary>
        public int IngredientCount
        {
            get
            {
                return ingredients.Count;
            }
        }

        /// <summary>
        /// A property for the list of ingredients. Gets. 
        /// </summary>
        public List<Ingredient> Ingredients
        {
            get
            {
                return ingredients;
            }
        }

        /// <summary>
        /// A property for the number of toppings on an order. Gets.
        /// </summary>
        public int ToppingCount
        {
            get
            {
                return toppings.Count;
            }
        }

        /// <summary>
        /// A property for the list of toppings. Gets.
        /// </summary>
        public List<Topping> Toppings
        {
            get
            {
                return toppings;
            }
        }

        // Constructors
        /// <summary>
        /// Create a new blank order
        /// </summary>
        public Order()
        {
            // Initialize the order's components to be empty
            ingredients = new List<Ingredient>();
            toppings = new List<Topping>();
            brewAmount = 0;
        }

        /// <summary>
        /// Create a new random order
        /// </summary>
        /// <param name="random">Whether or not the order is randomly generated</param>
        public Order(bool random)
        {
            // Initalize the order's components to be empty
            ingredients = new List<Ingredient>();
            toppings = new List<Topping>();
            brewAmount = 0;

            // Generate a random order.
            if (random)
            {
                Random rng = new Random();

                // If the string isn't full, and it isn't empty, there's a 1/5 chance to
                // stop adding ingredients
                while (ingredients.Count < 9 && (rng.Next(5) != 0 || ingredients.Count == 0))
                {
                    // Add a random ingredient
                    ingredients.Add((Ingredient)rng.Next(8));
                }
            }
        }

        /// <summary>
        /// Create a new specific order
        /// </summary>
        /// <param name="ingredients">The list of ingredients for the order</param>
        /// <param name="brewAmount">How much the order should be brewed</param>
        /// <param name="toppings">The list of toppings for the order</param>
        public Order(List<Ingredient> ingredients, int brewAmount, List<Topping> toppings)
        {
            this.ingredients = ingredients;
            this.toppings = toppings;
            this.brewAmount = brewAmount;
        }

        /// <summary>
        /// Returns the contained information in the order as a string.
        /// </summary>
        /// <returns>A string about an order.</returns>
        public override string ToString()
        {
            // Create a new string to put the other strings together
            string returnString = string.Empty;

            // Add each ingredient to the string
            returnString += "Ingredients:\n";
            foreach (Ingredient ingredient in ingredients)
            {
                returnString += ingredient.ToString();
                returnString += " ";
            }

            // Add the brew amount to the string 
            returnString += $"\nBrew Amount: \n{(int)brewAmount}\n";

            // Add the toppings to the string
            returnString += "Toppings:\n";
            foreach (Topping topping in toppings)
            {
                returnString += topping.ToString();
            }

            // Return the string
            return returnString;
        }

        /// <summary>
        /// Add an ingredient to a given order if there are not already 3 of that ingredient
        /// </summary>
        /// <param name="ingredient">The ingredient to add</param>
        public void AddIngredient(Ingredient ingredient)
        {
            // Create an integer to count the number of a given ingredient
            int ingredientCount = 0;

            // Count how much of the given ingredient are in the ingredient list
            foreach (Ingredient i in ingredients)
            {
                if (i == ingredient)
                {
                    ingredientCount++;
                }
            }

            // Add the ingredient if there are less than 3 of it.
            if (ingredientCount < 3 && ingredients.Count < 9)
            {
                ingredients.Add(ingredient);
            }
        }

        /// <summary>
        /// Remove an ingredient from the ingredients list
        /// </summary>
        /// <param name="ingredient">The ingredient to remove</param>
        public void RemoveIngredient(Ingredient ingredient)
        {
            ingredients.Remove(ingredient);
        }

        /// <summary>
        /// Add or remove an ingredient, based on the boolean value
        /// </summary>
        /// <param name="ingredient">The ingredient to modify</param>
        /// <param name="remove">Whether or not to remove the ingredient</param>
        public void ModifyIngredient(Ingredient ingredient, bool remove)
        {
            if (remove)
            {
                RemoveIngredient(ingredient);
            }
            else
            {
                AddIngredient(ingredient);
            }
        }



    }

}
