﻿
using var game = new MinervasMarvelousMixturette.Game1();
game.Run();
