﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.IO;

namespace MinervasMarvelousMixturette
{
    /// <summary>
    /// A class representing the score screen. Managed in Game1.
    /// </summary>
    public class Scores
    {
        // Fields
        //      Fields for loading and saving scores
        private List<int> scoresList;
        private StreamReader reader;
        private StreamWriter writer;
        private int selectedLevel;
        private string lineOfText;
        private int numDisplayScores;

        //      Asset fields
        // Font
        private SpriteFont arial12;
        private SpriteFont levelNumberFont;
        private SpriteFont selectedLevelNumberFont;

        // The images for the scores
        private List<Texture2D> scoreAssets;

        //      Delegates, assigned in Game1
        // Delegate for changing state
        public ChangeToStateDelegate ChangeState;

        // Delegate for single key presses
        public SingleKeyPressDelegate SingleKeyPress;

        /// <summary>
        /// Create a new scores class
        /// </summary>
        public Scores()
        {
            // Initialize the scores list
            scoresList = new List<int>();
        }

        /// <summary>
        /// Load the content for the score screen
        /// </summary>
        /// <param name="Content">The content manager to load the content with</param>
        public void LoadContent(ContentManager Content)
        {
            // Load the font
            arial12 = Content.Load<SpriteFont>("arial12");
            levelNumberFont = Content.Load<SpriteFont>("LevelNumberFont");
            selectedLevelNumberFont = Content.Load<SpriteFont>("SelectedLevelNumberFont");
            selectedLevel = -1;
        }

        /// <summary>
        /// Update the score screen
        /// </summary>
        /// <param name="gameTime">The current GameTime</param>
        public void Update(GameTime gameTime)
        {
            // If enter is pressed, change to the main menu state
            if (SingleKeyPress(Keys.Enter))
            {
                ChangeState(GameState.MainMenu);
            }

            // Check if a number key is pressed
            // If one is pressed then select the associated level
            for (int i = (int)(Keys.D1); i < (int)(Keys.D6); i++)
            {
                if (SingleKeyPress((Keys)i))
                {
                    selectedLevel = i - 48;
                    scoresList.Clear();

                    if (selectedLevel != -1)
                    {
                        ReadLevelScores();
                    }
                }
            }

            //// If space is pressed and a level is selected then read in the scores for that level
            //if (SingleKeyPress(Keys.Space) && selectedLevel != -1)
            //{
            //    ReadLevelScores();
            //}57
        }

        /// <summary>
        /// Draw the score screen
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        public void Draw(SpriteBatch sb)
        {
            // Draw the information text
            sb.DrawString(arial12, "Score Screen\nEnter to go to main menu.",
                Vector2.Zero, Color.Indigo);

            sb.DrawString(arial12, "\n\nPress a number to select a level",
                Vector2.Zero, Color.Indigo);

            //Writes "high scores" at top of screen
            //sb.DrawString(selectedLevelNumberFont, "High Scores", new Vector2((1280 / 2) - (64 * 3), 150), Color.Purple);
            DrawStringCentered(sb, selectedLevelNumberFont, "High Scores", new Vector2(640, 200), Color.Purple);

            // If a level has been selected, print the 5 highest scores for that level
            // (or all scores if less than 5 exist)
            if (selectedLevel != -1)
            {
                //Draws level number selected at top of screen
                switch (selectedLevel)
                {
                    case 1:
                        //sb.DrawString(selectedLevelNumberFont, "Level 1", new Vector2(1280 / 2 - 96, 80), Color.Purple);
                        DrawStringCentered(sb, selectedLevelNumberFont, "Level 1", new Vector2(640, 100), Color.Purple);
                        break;
                    case 2:
                        //sb.DrawString(selectedLevelNumberFont, "Level 2", new Vector2(1280 / 2 - 96, 80), Color.Purple);
                        DrawStringCentered(sb, selectedLevelNumberFont, "Level 2", new Vector2(640, 100), Color.Purple);
                        break;
                    case 3:
                        //sb.DrawString(selectedLevelNumberFont, "Level 3", new Vector2(1280 / 2 - 96, 80), Color.Purple);
                        DrawStringCentered(sb, selectedLevelNumberFont, "Level 3", new Vector2(640, 100), Color.Purple);
                        break;
                    case 4:
                        //sb.DrawString(selectedLevelNumberFont, "Level 4", new Vector2(1280 / 2 - 96, 80), Color.Purple);
                        DrawStringCentered(sb, selectedLevelNumberFont, "Level 4", new Vector2(640, 100), Color.Purple);
                        break;
                    case 5:
                        //sb.DrawString(selectedLevelNumberFont, "Level 5", new Vector2(1280 / 2 - 96, 80), Color.Purple);
                        DrawStringCentered(sb, selectedLevelNumberFont, "Level 5", new Vector2(640, 100), Color.Purple);
                        break;
                }

                try
                {
                    // Print the top 5 scores
                    // Find the number of scores to display, maximum of 5.
                    numDisplayScores = Math.Min(scoresList.Count, 5);


                    // Display the scores
                    for (int i = 0; i < numDisplayScores; i++)
                    {
                        //sb.DrawString(levelNumberFont, $"{scoresList[i]}", new Vector2(0, 200 + 30 * i), Color.Purple);
                        //sb.DrawString(levelNumberFont, scoresList[i].ToString(), new Vector2((1280 / 2) - 64, 300 + 50 * i), Color.Purple);
                        DrawStringCentered(sb, levelNumberFont, scoresList[i].ToString(), new Vector2(640, 300 + 50 * i), Color.Purple);
                    }
                }

                //if caught
                catch (Exception e)
                {
                    //change the game scene to main menu
                    ChangeState(GameState.MainMenu);

                    //restart the score scene
                    selectedLevel = -1;
                    scoresList = new List<int>();
                }
            }
            else
            {
                //Drawing all level numbers, deselected
                sb.DrawString(levelNumberFont, "1", new Vector2(1280 / 6, 300), Color.Purple);
                sb.DrawString(levelNumberFont, "2", new Vector2(2 * (1280 / 6), 300), Color.Purple);
                sb.DrawString(levelNumberFont, "3", new Vector2(3 * (1280 / 6), 300), Color.Purple);
                sb.DrawString(levelNumberFont, "4", new Vector2(4 * (1280 / 6), 300), Color.Purple);
                sb.DrawString(levelNumberFont, "5", new Vector2(5 * (1280 / 6), 300), Color.Purple);
            }
        }

        /// <summary>
        /// Read the level scores for a given level
        /// </summary>
        private void ReadLevelScores()
        {
            // Create a string to score the current line
            lineOfText = "";
            scoresList = new List<int>();

            try
            {
                // Attempt to load the level's scores
                reader =
                    new StreamReader($"../../../../resources/Scores/Scores{selectedLevel}.txt");

                // Add each score from the file to the score list
                while ((lineOfText = reader.ReadLine()) != null)
                {
                    AddScore(int.Parse(lineOfText));
                }
                SortScoreList();
            }
            catch
            {
                // Set the score list to null if the scorelist can't be loaded
                scoresList = null;
            }
            finally
            {
                // Close the reader if it is not null
                if (reader != null)
                {
                    reader.Close();
                }
            }
        }

        /// <summary>
        /// Add a score to the relevant file, and keep only 5 scores
        /// </summary>
        /// <param name="score">The score to add</param>
        public void AddScore(int score)
        {
            // Adds the score to the list
            scoresList.Add(score);

            // Sort the list
            SortScoreList();

            // If there are more than 5 scores
            while (scoresList.Count > 5)
            {
                // Remove the sixth item from the list
                scoresList.Remove(scoresList[5]);
            }
        }

        /// <summary>
        /// Property for the number of scores. Gets.
        /// </summary>
        private int NumOfScores
        {
            // Return the number of scores in the score list.
            get
            {
                return scoresList.Count;
            }
        }

        /// <summary>
        /// Sort the score list
        /// </summary>
        private void SortScoreList()
        {
            // Create a list to store the sorted list
            List<int> sortedList = new List<int>();

            // Create a temporary variable to hold the highest value
            int highest = 0;

            // Sort all of the scores
            while (scoresList.Count > 0)
            {
                // Find the highest value
                foreach (int i in scoresList)
                {
                    if (i > highest)
                    {
                        highest = i;
                    }
                }

                // Add it to the sorted list
                sortedList.Add(highest);

                // Remove it from the original list
                scoresList.Remove(highest);

                // Reset the highest value
                highest = 0;
            }

            // Set the scorelist to the sorted list
            scoresList = sortedList;
        }

        /// <summary>
        /// Save the current scores list.
        /// </summary>
        private void SaveScores()
        {
            // Sort the score list, just in case.
            SortScoreList();
            try
            {
                // Attempt to open the relevant score file
                writer =
                    new StreamWriter($"../../../../resources/Scores/Scores{selectedLevel}.txt");

                // If the writer is not null and the score list is not null
                if (writer != null && scoresList != null)
                {
                    // Write each score to the list.
                    for (int i = 0; i < NumOfScores; i++)
                    {
                        writer.WriteLine(scoresList[i]);
                    }
                }
            }
            catch
            {
                // If there was an error, set the score list to null
                //might be a better option to fix this exception later on...
                scoresList = null;
            }
            finally
            {
                // Close the writer if it exists
                if (writer != null)
                {
                    writer.Close();
                }
            }
        }


        /// <summary>
        /// Draw a string centered.
        /// </summary>
        /// <param name="sb">The spritebatch to draw with</param>
        /// <param name="spriteFont">The spritefont to use</param>
        /// <param name="text">The text to draw</param>
        /// <param name="position">The location of the center of the text</param>
        /// <param name="color">The color of the text</param>
        private void DrawStringCentered(SpriteBatch sb, SpriteFont spriteFont, string text, Vector2 position, Color color)
        {
            Vector2 stringSize = spriteFont.MeasureString(text);

            sb.DrawString(spriteFont, text, new Vector2((int)position.X - stringSize.X / 2, position.Y - stringSize.Y / 2), color);
        }



    }
}
